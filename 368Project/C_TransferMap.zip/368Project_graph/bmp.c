/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "bmp.h"

bool _error(BMPHeader * bmp_hdr, FILE* fp, char** error);

BMPImage* read_bmp(FILE* fp, char** error){
	if(fp == NULL){	
		return NULL;
	}
	BMPImage *image = malloc(sizeof(*image));
	int read = fread(&(image->header), sizeof(BMPHeader), 1, fp);
	if(read == 0){
		free(image);
		return NULL;
	}
//	if(check_bmp_header(&(image->header), fp) == false){
//		_error(&(image->header), fp, error);
//		free(image);
//		return NULL;
//	}
	image->data = (unsigned char*)malloc((image->header.size - BMP_HEADER_SIZE) * sizeof(char));
	fseek(fp, BMP_HEADER_SIZE, SEEK_SET);
	fread(image->data, image->header.size - image->header.offset, 1, fp);
	printf("%s", image->data);
	return image;	
}

bool check_bmp_header(BMPHeader* bmp_hdr, FILE* fp){
	if(bmp_hdr->type != 0x4d42){
		return false;
	}
	else if(bmp_hdr->offset != BMP_HEADER_SIZE){
		return false;
	}
	else if(bmp_hdr->dib_header_size != DIB_HEADER_SIZE){
		return false;
	}
	else if(bmp_hdr->num_planes != 1){
		return false;
	}
	else if(bmp_hdr->compression != 0){
		return false;
	}
	else if(bmp_hdr->num_colors != 0 || bmp_hdr->important_colors != 0){
		return false;
	}
	else if(bmp_hdr->bits_per_pixel != 16 && bmp_hdr->bits_per_pixel != 24){
		return false;
	}
	fseek(fp, 0, SEEK_END);
	if((bmp_hdr->image_size_bytes != (bmp_hdr->width_px) * (bmp_hdr->height_px) * (bmp_hdr->bits_per_pixel) / 8 + 2 * bmp_hdr->height_px) || bmp_hdr->image_size_bytes  + BMP_HEADER_SIZE != bmp_hdr->size || bmp_hdr->size != ftell(fp)){
		fseek(fp, 0, SEEK_SET);
		return false;
	}
	return true;
}

bool write_bmp(FILE* fp, BMPImage* image, char** error){
	fwrite(&(image->header), image->header.offset, 1, fp);
	fseek(fp, 0, SEEK_END);
	fwrite(image->data, (image->header.size - image->header.offset), 1, fp);
	return true;
}

bool _error(BMPHeader* bmp_hdr, FILE* fp, char** error){
	char* message;
	if(bmp_hdr->type != 0x4d42){
		message = "Type is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	else if(bmp_hdr->offset != BMP_HEADER_SIZE){
		message = "Offset is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	else if(bmp_hdr->dib_header_size != DIB_HEADER_SIZE){
//		message = "Size is wrong!";
//		*error = malloc((strlen(message) + 1) * sizeof(**error));
//		strcpy(*error, message);
		return true;
	}
	else if(bmp_hdr->num_planes != 1){
		message = "Plane number is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	else if(bmp_hdr->compression != 0){
		message = "Compression is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	else if(bmp_hdr->num_colors != 0 || bmp_hdr->important_colors != 0){
		message = "Color is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	else if(bmp_hdr->bits_per_pixel != 16 && bmp_hdr->bits_per_pixel != 24){
		message = "Bits per pixel is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		return false;
	}
	fseek(fp, 0, SEEK_END);
	if((bmp_hdr->image_size_bytes != (bmp_hdr->width_px) * (bmp_hdr->height_px) * (bmp_hdr->bits_per_pixel) / 8 + 2 * bmp_hdr->height_px) || bmp_hdr->image_size_bytes  + BMP_HEADER_SIZE != bmp_hdr->size || bmp_hdr->size != ftell(fp)){
		message = "Size is wrong!";
		*error = malloc((strlen(message) + 1) * sizeof(**error));
		strcpy(*error, message);
		fseek(fp, 0, SEEK_SET);
		return false;
	}
	return true;
}

BMPImage* crop_bmp(BMPImage* image, int x, int y, int w, int h, char** error){
	if(x < 0 || w < 0 || y < 0 || h < 0 || image->header.width_px < (x + w) || image->header.height_px < (y - h)){
		return NULL;
	}
	BMPImage* crop_image = malloc(sizeof(*image));
	crop_image->header = image->header;
	crop_image->header.width_px = w;
	crop_image->header.height_px = h;
	crop_image->header.image_size_bytes = (crop_image->header.width_px) * (crop_image->header.height_px) * (crop_image->header.bits_per_pixel) / 8 + 2 * crop_image->header.height_px;
	crop_image->header.size = crop_image->header.image_size_bytes + BMP_HEADER_SIZE;

	crop_image->data = (unsigned char*)malloc(crop_image->header.image_size_bytes * sizeof(char));
	int new = 0;
	int old = 0;
	old = old + (image->header.height_px - y + h) * image->header.width_px * image->header.bits_per_pixel / 8;
	for(int j = 0; j < h; j++){
		old = old + x * image->header.bits_per_pixel / 8;
		for(int i = 0; i < w; i++){
			crop_image->data[new] = image->data[old];
			new++;
			old++;
		}
		crop_image->data[new] = 0;
		new++;
		crop_image->data[new] = 0;
		new++;
		old = old + 2 + (image->header.width_px - x - w) * (image->header.bits_per_pixel) / 8;
	}
	free_bmp(image);
	return crop_image;
}
void free_bmp(BMPImage* image){
	free(image->data);
	free(image);
	return ;
}

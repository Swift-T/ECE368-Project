/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */

#include <assert.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mtat.h"
#include "bmp.h"


typedef struct{
	BMPImage* image;
	int offset;
	int num;
	int run;
}gray_args;

typedef struct{
	BMPImage* image;
	int radius;
	int offset;
	int num;
	int run;
}binarize_args;


void* to_gray_worker(void* arg){
	gray_args* args = arg;
	if(args->run){
		int width = args->image->header.width_px;
		int pixel = args->image->header.bits_per_pixel / 8;
		int row = width * pixel + 2;
		int mean;
		unsigned char* data = args->image->data;
		for(int i = 0; i < args->num; i++){
			for(int j = 0; j < pixel * width; j += pixel){
				mean = 0;
				for(int m = 0; m < pixel; m++){
					mean += data[args->offset * row + i * row + j + m];
				}
				for(int k = 0; k < pixel; k++){
					if(mean > 220){
						data[args->offset * row + i * row + j + k] = 250;
					}
					else{
						data[args->offset * row + i * row + j + k] = 0;
					}
				}
			}
		}
	}
	return NULL;
}

void* binarize_worker(void* arg){
	binarize_args* args = arg;
	if(args->run){
		int width = args->image->header.width_px;
		int height = args->image->header.height_px;
		int pixel = args->image->header.bits_per_pixel / 8;
		int row = width * pixel + 2;
		int radius = args->radius * pixel;
		int mean;
		int x_position;
		int y_position;
		int upper;
		int under;
		int left;
		int right;
		unsigned char* data = args->image->data;
		for(int i = 0; i < args->num; i++){
			for(int j = 0; j < pixel * width; j += pixel){
				mean = 0;
				x_position = data[args->offset * row + i * row + j] % row;
				y_position = data[args->offset * row + i * row + j] / row;
				left = x_position - radius;
				right = x_position + radius + pixel;
				upper = y_position - radius / pixel;
				under = y_position + radius / pixel;
				if(left < 0){
					left = 0;
				}
				if(right > row - 2){
					right = row - 2;
				}
				if(upper < 0){
					upper = 0;
				}
				if(under > height){
					under = height;
				}
				for(int y = upper; y < under; y++){
					for(int x = left; x < right; x++){
						mean += data[y * row + x]; 
					}
				}
				if((under - upper) != 0){
					mean /= (right - left) * (under - upper) * pixel;
				}
				for(int k = 0; k < pixel; k++){
					if(data[args->offset * row + i * row + j + k] > mean){
						data[args->offset * row + i * row + j + k] = 250;
					}
					else{
						data[args->offset * row + i * row + j + k] = 0;
					}
				}
			}
		}
	}
	return NULL;
}

BMPImage* to_gray(BMPImage* image, int num_threads, char** error){
	gray_args arg[num_threads];
	int size = image->header.height_px;
	if(size >= num_threads){
		for(int i = 0; i < num_threads; i++){
			arg[i].image = image;
			arg[i].offset = size / num_threads * i;
			arg[i].num = size / num_threads;
			arg[i].run = true;
		}
		arg[num_threads - 1].num = size / num_threads + size % num_threads;
	}
	else{
		for(int i = 0; i < size; i++){
			arg[i].image = image;
			arg[i].offset = i;
			arg[i].num = 1;
			arg[i].run = true;
		}
		for(int i = size; i < num_threads; i++){
			arg[i].image = NULL;
			arg[i].offset = 0;
			arg[i].num = 0;
			arg[i].run = false;
		}	
	}

	pthread_t t[num_threads];
	for(int i = 0; i < num_threads; i++){
		if(pthread_create(&t[i], NULL, to_gray_worker, (void*)&arg[i]) != 0){
			if(*error == NULL){
				char* message = "to_gray failed because pthread_create do not return 0";
				*error = malloc((strlen(message) + 1) * sizeof(**error));
				strcpy(*error, message);
			}
			return false;
		}
	}
	for(int i = 0; i < num_threads; i++){
		pthread_join(t[i], NULL);
	}
	return image;
}

BMPImage* binarize(BMPImage* image, int radius, int num_threads, char** error){
	binarize_args arg[num_threads];
	int size = image->header.height_px;
	if(size >= num_threads){
		for(int i = 0; i < num_threads; i++){
			arg[i].image = image;
			arg[i].radius = radius;
			arg[i].offset = size / num_threads * i;
			arg[i].num = size / num_threads;
			arg[i].run = true;
		}
		arg[num_threads - 1].num = size / num_threads + size % num_threads;
	}
	else{
		for(int i = 0; i < size; i++){
			arg[i].image = image;
			arg[i].radius = radius;
			arg[i].offset = i;
			arg[i].num = 1;
			arg[i].run = true;
		}
		for(int i = size; i < num_threads; i++){
			arg[i].image = NULL;
			arg[i].radius = 0;
			arg[i].offset = 0;
			arg[i].num = 0;
			arg[i].run = false;
		}	
	}

	pthread_t t[num_threads];
	for(int i = 0; i < num_threads; i++){
		if(pthread_create(&t[i], NULL, binarize_worker, (void*)&arg[i]) != 0){
			if(*error == NULL){
				char* message = "binarize failed because pthread_create do not return 0";
				*error = malloc((strlen(message) + 1) * sizeof(**error));
				strcpy(*error, message);
			}
			return false;
		}
	}
	for(int i = 0; i < num_threads; i++){
		pthread_join(t[i], NULL);
	}
	return image;
}

/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */
#include "bmp.h"

BMPImage* to_gray(BMPImage*, int, char**);
BMPImage* binarize(BMPImage*, int, int, char**);


/* vim: set tabstop=4 shiftwidth=4 fileencoding=utf-8 noexpandtab: */

#include <assert.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "bmp.h"
#include "mtat.h"

int main(int argc, char *argv[]){
	//Stage 01: Read a bmp file
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//BMPImage* image = read_bmp(fp, &error);
	//free_bmp(image);
	//fclose(fp);
	//return EXIT_SUCCESS;
	
	//Stage 02: Add function to_gray and return NULL
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//BMPImage* image = read_bmp(fp, &error);
	//to_gray(image, 2, &error);
	//free_bmp(image);
	//fclose(fp);
	//return EXIT_SUCCESS;
	
	//Stage 03: Create threads in to_gray
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//BMPImage* image = read_bmp(fp, &error);
	//to_gray(image, 2, &error);
	//free_bmp(image);
	//fclose(fp);
	//return EXIT_SUCCESS;
	
	//Stage 04: Add function to to_gray_worker
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//BMPImage* image = read_bmp(fp, &error);
	//to_gray(image, 2, &error);
	//free_bmp(image);
	//fclose(fp);
	//return EXIT_SUCCESS;
	
	//Stage 05: Output the gray bmp
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 1, &error);
	//write_bmp(gray, gray_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//return EXIT_SUCCESS;
	
	//Stage 06: Add binarize function
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//return EXIT_SUCCESS;
	
	//Stage 07: Add binarize worker
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//return EXIT_SUCCESS;

	//Stage 08: left side out of range
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//FILE* black = fopen("black_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//BMPImage* black_image = binarize(gray_image, 1, 10, &error);
	//write_bmp(black, black_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//fclose(black);
	//return EXIT_SUCCESS;
	
	//Stage 09: right side out of range
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//FILE* black = fopen("black_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//BMPImage* black_image = binarize(gray_image, 1, 10, &error);
	//write_bmp(black, black_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//fclose(black);
	//return EXIT_SUCCESS;
	
	//Stage 10: upper side out of range
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//FILE* black = fopen("black_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//BMPImage* black_image = binarize(gray_image, 1, 10, &error);
	//write_bmp(black, black_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//fclose(black);
	//return EXIT_SUCCESS;
	
	//Stage 11: under side out of range
	//FILE* fp;
	//char* error = NULL;
	//fp = fopen("car.bmp", "r");
	//FILE* gray = fopen("gray_car.bmp", "w");
	//FILE* black = fopen("black_car.bmp", "w");
	//BMPImage* image = read_bmp(fp, &error);
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//BMPImage* black_image = binarize(gray_image, 1, 10, &error);
	//write_bmp(black, black_image, &error);
	//free_bmp(image);
	//fclose(fp);
	//fclose(gray);
	//fclose(black);
	//return EXIT_SUCCESS;
	
	//Stage 12: test with error bmp file
	FILE* fp;
	char* error = NULL;
	fp = fopen("matrix.bmp", "r");
	BMPImage* image = read_bmp(fp, &error);
	if(image == NULL){
		fprintf(stderr, "%s\n", error);
		free(error);
		fclose(fp);
		return EXIT_FAILURE;
	}
	FILE* gray = fopen("matrix.txt", "w");
	FILE* black = fopen("black_PU.bmp", "w");
	//BMPImage* gray_image = to_gray(image, 10, &error);
	//write_bmp(gray, gray_image, &error);
	//BMPImage* black_image = binarize(gray_image, 2, 100, &error);
	//write_bmp(black, black_image, &error);
	int k = image->header.height_px * image->header.width_px * 3;
	printf("%d\n%d", image->header.height_px, image->header.width_px);
	for(int i = 0; i < image->header.height_px; i = i + 6){
		if(k > image->header.width_px * 3 * 6){
			k = k - image->header.width_px * 3 * 6;
			for(int j = 0; j < image->header.width_px * 3; j = j + 3*6){
				if(image->data[k] > 0){
					fprintf(gray, "%d", 1);
				}
				else{
					fprintf(gray, "%d", 0);
				}
				k = k + 3*6;
			}
			k = k - image->header.width_px * 3 * 6;
			fprintf(gray, "\n");
		}
		else{
			break;
		}
	}
	if(k == image->header.height_px * image->header.width_px){
		printf("yes");
	}
	else{
		printf("no");
	}
	printf("%d\n", image->header.size - image->header.offset);
	printf("%d\n%d", image->header.height_px, image->header.width_px);
	free_bmp(image);
	fclose(fp);
	fclose(gray);
	fclose(black);
	return EXIT_SUCCESS;
}

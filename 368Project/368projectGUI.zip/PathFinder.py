# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'PathFinder.ui'
#
# Created: Tue Apr 19 21:03:34 2016
#      by: pyside-uic 0.2.15 running on PySide 1.2.2
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_PathFinder(object):
    def setupUi(self, PathFinder):
        PathFinder.setObjectName("PathFinder")
        PathFinder.resize(555, 586)
        self.centralwidget = QtGui.QWidget(PathFinder)
        self.centralwidget.setObjectName("centralwidget")
        self.SourceBox = QtGui.QComboBox(self.centralwidget)
        self.SourceBox.setGeometry(QtCore.QRect(60, 20, 161, 27))
        self.SourceBox.setObjectName("SourceBox")
        self.DesBox = QtGui.QComboBox(self.centralwidget)
        self.DesBox.setGeometry(QtCore.QRect(260, 20, 151, 27))
        self.DesBox.setObjectName("DesBox")
        self.DrawingArea = QtGui.QGroupBox(self.centralwidget)
        self.DrawingArea.setGeometry(QtCore.QRect(10, 30, 521, 481))
        self.DrawingArea.setTitle("")
        self.DrawingArea.setObjectName("DrawingArea")
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 25, 32, 17))
        self.label.setObjectName("label")
        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(240, 25, 32, 17))
        self.label_2.setObjectName("label_2")
        self.RunBtn = QtGui.QPushButton(self.centralwidget)
        self.RunBtn.setGeometry(QtCore.QRect(450, 20, 71, 27))
        self.RunBtn.setObjectName("RunBtn")
        self.SaveBtn = QtGui.QPushButton(self.centralwidget)
        self.SaveBtn.setGeometry(QtCore.QRect(20, 520, 61, 31))
        self.SaveBtn.setObjectName("SaveBtn")
        PathFinder.setCentralWidget(self.centralwidget)
        self.statusbar = QtGui.QStatusBar(PathFinder)
        self.statusbar.setObjectName("statusbar")
        PathFinder.setStatusBar(self.statusbar)

        self.retranslateUi(PathFinder)
        QtCore.QMetaObject.connectSlotsByName(PathFinder)

    def retranslateUi(self, PathFinder):
        PathFinder.setWindowTitle(QtGui.QApplication.translate("PathFinder", "Boiler Rush", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PathFinder", "From", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("PathFinder", "to", None, QtGui.QApplication.UnicodeUTF8))
        self.RunBtn.setText(QtGui.QApplication.translate("PathFinder", "Run", None, QtGui.QApplication.UnicodeUTF8))
        self.SaveBtn.setText(QtGui.QApplication.translate("PathFinder", "Save", None, QtGui.QApplication.UnicodeUTF8))

